﻿const bcrypt = require("bcryptjs");
const { Utilisateur, Etudiant, Role } = require("./models");

(async () => {
  try {
    const email = "test2@example.com";
    let utilisateur = await Utilisateur.findOne({ where: { email } });

    if (!utilisateur) {
      const role = await Role.findOne();
      if (!role) throw new Error("Aucun role disponible");

      utilisateur = await Utilisateur.create({
        nom: "Etudiant Test",
        email,
        mot_de_passe: await bcrypt.hash("Test1234!", 10),
        role_id: role.id
      });
    }

    let etudiant = await Etudiant.findOne({
      where: { utilisateur_id: utilisateur.id }
    });

    if (!etudiant) {
      etudiant = await Etudiant.create({
        utilisateur_id: utilisateur.id,
        matricule: "ETU002",
        programme: "Programmation informatique"
      });
    }

    console.log("SUCCES :", etudiant.toJSON());
  } catch (erreur) {
    console.error("ERREUR :", erreur.message);
  }
})();
