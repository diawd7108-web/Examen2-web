
const models = require("../models");

const creerCRUD = (nomModele) => {
  const Modele = models[nomModele];

  return {
    ajouter: async (req, res) => {
      try {
        const resultat = await Modele.create(req.body);
        res.status(201).json(resultat);
      } catch (erreur) {
        res.status(400).json({ erreur: erreur.message });
      }
    },

    afficherTous: async (req, res) => {
      try {
        const resultats = await Modele.findAll();
        res.json(resultats);
      } catch (erreur) {
        res.status(500).json({ erreur: erreur.message });
      }
    },

    afficherUn: async (req, res) => {
      try {
        const resultat = await Modele.findByPk(req.params.id);
        if (!resultat) {
          return res.status(404).json({ message: "Introuvable" });
        }
        res.json(resultat);
      } catch (erreur) {
        res.status(500).json({ erreur: erreur.message });
      }
    },

    modifier: async (req, res) => {
      try {
        const resultat = await Modele.findByPk(req.params.id);
        if (!resultat) {
          return res.status(404).json({ message: "Introuvable" });
        }
        await resultat.update(req.body);
        res.json(resultat);
      } catch (erreur) {
        res.status(400).json({ erreur: erreur.message });
      }
    },

    supprimer: async (req, res) => {
      try {
        const resultat = await Modele.findByPk(req.params.id);
        if (!resultat) {
          return res.status(404).json({ message: "Introuvable" });
        }
        await resultat.destroy();
        res.json({ message: "Suppression réussie" });
      } catch (erreur) {
        res.status(500).json({ erreur: erreur.message });
      }
    }
  };
};

module.exports = creerCRUD;
