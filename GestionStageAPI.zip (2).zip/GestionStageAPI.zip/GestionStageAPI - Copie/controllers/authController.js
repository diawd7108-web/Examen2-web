
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { Utilisateur } = require("../models");

exports.connexion = async (req, res) => {
  try {
    const { email, mot_de_passe } = req.body;

    if (!email || !mot_de_passe) {
      return res.status(400).json({
        message: "Email et mot de passe obligatoires"
      });
    }

    const utilisateur = await Utilisateur.findOne({
      where: { email }
    });

    if (!utilisateur) {
      return res.status(401).json({
        message: "Identifiants incorrects"
      });
    }

    const valide = await bcrypt.compare(
      mot_de_passe,
      utilisateur.mot_de_passe
    );

    if (!valide) {
      return res.status(401).json({
        message: "Identifiants incorrects"
      });
    }

    if (!process.env.JWT_SECRET) {
      return res.status(500).json({
        message: "Configuration JWT manquante"
      });
    }

    const token = jwt.sign(
      {
        id: utilisateur.id,
        role_id: utilisateur.role_id
      },
      process.env.JWT_SECRET,
      { expiresIn: "2h" }
    );

    res.json({ token });
  } catch (erreur) {
    res.status(500).json({ erreur: erreur.message });
  }
};
