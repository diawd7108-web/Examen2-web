CREATE DATABASE IF NOT EXISTS gestion_stages;
USE gestion_stages;
CREATE TABLE roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE utilisateurs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    mot_de_passe VARCHAR(255) NOT NULL,
    role_id INT NOT NULL,
    photo VARCHAR(255),
    FOREIGN KEY (role_id) REFERENCES roles(id)
);

CREATE TABLE etudiants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id INT NOT NULL UNIQUE,
    matricule VARCHAR(50) NOT NULL UNIQUE,
    programme VARCHAR(100),
    cv VARCHAR(255),
    FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id)
);

CREATE TABLE entreprises (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(150) NOT NULL,
    adresse VARCHAR(255),
    email VARCHAR(150),
    telephone VARCHAR(30),
    logo VARCHAR(255)
);

CREATE TABLE offres_stage (
    id INT AUTO_INCREMENT PRIMARY KEY,
    entreprise_id INT NOT NULL,
    titre VARCHAR(150) NOT NULL,
    description TEXT,
    date_debut DATE,
    date_fin DATE,
    image VARCHAR(255),
    FOREIGN KEY (entreprise_id) REFERENCES entreprises(id)
);

CREATE TABLE candidatures (
    id INT AUTO_INCREMENT PRIMARY KEY,
    etudiant_id INT NOT NULL,
    offre_id INT NOT NULL,
    date_candidature DATETIME DEFAULT CURRENT_TIMESTAMP,
    statut VARCHAR(50) DEFAULT 'en_attente',
    FOREIGN KEY (etudiant_id) REFERENCES etudiants(id),
    FOREIGN KEY (offre_id) REFERENCES offres_stage(id)
);

CREATE TABLE stages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    candidature_id INT NOT NULL UNIQUE,
    date_debut DATE,
    date_fin DATE,
    statut VARCHAR(50) DEFAULT 'en_cours',
    FOREIGN KEY (candidature_id) REFERENCES candidatures(id)
);