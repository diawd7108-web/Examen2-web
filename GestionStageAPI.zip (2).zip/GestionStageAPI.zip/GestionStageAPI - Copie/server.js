const express = require("express");
const cors = require("cors");
require("dotenv").config();

const app = express();

app.use(cors());
app.use(express.json());
const authRoutes = require("./routes/authRoutes");
app.use("/api/auth", authRoutes);

const crudRoutes = require("./routes/crudRoutes");
app.use("/api", crudRoutes);
app.get("/", (req, res) => {
  res.json({ message: "Bienvenue sur GestionStageAPI" });
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Serveur démarré sur le port ${PORT}`);
});

const sequelize = require("./database");

sequelize.authenticate()
  .then(() => {
    console.log("Connexion MySQL réussie !");
  })
  .catch((error) => {
    console.error("Erreur de connexion MySQL :", error.message);
  });