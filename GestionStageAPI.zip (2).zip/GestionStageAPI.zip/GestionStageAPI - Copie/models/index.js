
const { DataTypes } = require("sequelize");
const sequelize = require("../database");

const options = (tableName) => ({
  tableName,
  timestamps: false
});

const Role = sequelize.define("Role", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  nom: { type: DataTypes.STRING(50), allowNull: false, unique: true }
}, options("roles"));

const Utilisateur = sequelize.define("Utilisateur", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  nom: { type: DataTypes.STRING(100), allowNull: false },
  email: { type: DataTypes.STRING(150), allowNull: false, unique: true },
  mot_de_passe: { type: DataTypes.STRING(255), allowNull: false },
  role_id: { type: DataTypes.INTEGER, allowNull: false },
  photo: DataTypes.STRING(255)
}, options("utilisateurs"));

const Etudiant = sequelize.define("Etudiant", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  utilisateur_id: { type: DataTypes.INTEGER, allowNull: false, unique: true },
  matricule: { type: DataTypes.STRING(50), allowNull: false, unique: true },
  programme: DataTypes.STRING(100),
  cv: DataTypes.STRING(255)
}, options("etudiants"));

const Entreprise = sequelize.define("Entreprise", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  nom: { type: DataTypes.STRING(150), allowNull: false },
  adresse: DataTypes.STRING(255),
  email: DataTypes.STRING(150),
  telephone: DataTypes.STRING(30),
  logo: DataTypes.STRING(255)
}, options("entreprises"));

const OffreStage = sequelize.define("OffreStage", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  entreprise_id: { type: DataTypes.INTEGER, allowNull: false },
  titre: { type: DataTypes.STRING(150), allowNull: false },
  description: DataTypes.TEXT,
  date_debut: DataTypes.DATEONLY,
  date_fin: DataTypes.DATEONLY,
  image: DataTypes.STRING(255)
}, options("offres_stage"));

const Candidature = sequelize.define("Candidature", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  etudiant_id: { type: DataTypes.INTEGER, allowNull: false },
  offre_id: { type: DataTypes.INTEGER, allowNull: false },
  date_candidature: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  },
  statut: {
    type: DataTypes.STRING(50),
    defaultValue: "en_attente"
  }
}, options("candidatures"));

const Stage = sequelize.define("Stage", {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  candidature_id: { type: DataTypes.INTEGER, allowNull: false, unique: true },
  date_debut: DataTypes.DATEONLY,
  date_fin: DataTypes.DATEONLY,
  statut: {
    type: DataTypes.STRING(50),
    defaultValue: "en_cours"
  }
}, options("stages"));

// Relations entre les tables
Role.hasMany(Utilisateur, { foreignKey: "role_id" });
Utilisateur.belongsTo(Role, { foreignKey: "role_id" });

Utilisateur.hasOne(Etudiant, { foreignKey: "utilisateur_id" });
Etudiant.belongsTo(Utilisateur, { foreignKey: "utilisateur_id" });

Entreprise.hasMany(OffreStage, { foreignKey: "entreprise_id" });
OffreStage.belongsTo(Entreprise, { foreignKey: "entreprise_id" });

Etudiant.hasMany(Candidature, { foreignKey: "etudiant_id" });
Candidature.belongsTo(Etudiant, { foreignKey: "etudiant_id" });

OffreStage.hasMany(Candidature, { foreignKey: "offre_id" });
Candidature.belongsTo(OffreStage, { foreignKey: "offre_id" });

Candidature.hasOne(Stage, { foreignKey: "candidature_id" });
Stage.belongsTo(Candidature, { foreignKey: "candidature_id" });

module.exports = {
  Role,
  Utilisateur,
  Etudiant,
  Entreprise,
  OffreStage,
  Candidature,
  Stage
};
