const authMiddleware = require("../middlewares/authMiddleware");
const express = require("express");
const creerCRUD = require("../controllers/crudController");
const { body } = require("express-validator");
const valider = require("../middlewares/validationMiddleware");
const router = express.Router();
router.use(authMiddleware);
const ressources = {
  roles: "Role",
  utilisateurs: "Utilisateur",
  etudiants: "Etudiant",
  entreprises: "Entreprise",
  offres: "OffreStage",
  candidatures: "Candidature",
  stages: "Stage"
};

for (const [chemin, modele] of Object.entries(ressources)) {
  const controller = creerCRUD(modele);

 router.post(
  `/${chemin}`,
  (req, res, next) => {
    if (!req.body || Object.keys(req.body).length === 0) {
      return res.status(400).json({
      message: "Les données sont obligatoires"
      });
    }
    if (chemin === "etudiants") {
  if (!req.body.utilisateur_id || !req.body.matricule) {
    return res.status(400).json({
      message: "utilisateur_id et matricule sont obligatoires"
    });
  }
}
    next();
  },
  controller.ajouter
);
  router.get(`/${chemin}`, controller.afficherTous);
  router.get(`/${chemin}/:id`, controller.afficherUn);
  router.put(`/${chemin}/:id`, controller.modifier);
  router.delete(`/${chemin}/:id`, controller.supprimer);
}

module.exports = router;
