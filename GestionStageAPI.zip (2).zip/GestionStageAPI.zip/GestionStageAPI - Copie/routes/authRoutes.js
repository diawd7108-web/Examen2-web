const express = require("express");
const router = express.Router();
const authController = require("../controllers/authController");

router.post("/connexion", authController.connexion);

module.exports = router;