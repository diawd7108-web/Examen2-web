const { Utilisateur, Role } = require("./models");
const bcrypt = require("bcryptjs");

(async () => {
  try {
    const role = await Role.findOne();
    if (!role) throw new Error("Aucun role disponible");

    const email = `test${Date.now()}@example.com`;

    const utilisateur = await Utilisateur.create({
      nom: "Etudiant Test",
      email,
      mot_de_passe: await bcrypt.hash("Test1234!", 10),
      role_id: role.id
    });

    console.log(utilisateur.id);
  } catch (e) {
    console.error("ERREUR :", e.message);
    process.exitCode = 1;
  }
})();
